# LaTeX Drill Lab — instrukcja dla studentów

1. Otwórz stronę ćwiczenia i wpisz **inicjały** (np. `RD`) oraz **kod od prowadzącego: `0000`**. Nie wpisuj loginu GitHub ani nazwiska.
2. W kolejnych **18 zadaniach** uzupełniaj wyłącznie brakującą część kodu LaTeX-a. Reszta pozostaje widoczna i nie wymaga przepisywania.
3. Kliknij **Dalej** lub naciśnij **Enter**. Możesz popełnić maksymalnie pięć błędów na zadanie; po piątym zadanie zostanie pominięte.
4. Jeśli nie znasz odpowiedzi, pozostaw lukę pustą i wybierz **Dalej**. Takie pominięcie nie zużywa próby.
5. Możesz wybrać **Cofnij**, aby wrócić do wcześniejszego pytania. Liczba prób pozostaje zachowana; możesz też poprawiać zadania wcześniej pominięte pustą odpowiedzią.
6. Po zakończeniu wszystkich pytań kliknij **Pobierz raport .txt** i umieść pobrany plik w miejscu wskazanym przez prowadzącego. **Nie zmieniaj zawartości pliku**.

Pamiętaj: inicjały nie identyfikują jednoznacznie osoby. Umieszczaj raport wyłącznie we własnym repozytorium/folderze, zgodnie z instrukcją prowadzącego. Postęp zapisuje się lokalnie w bieżącej przeglądarce; przed wyborem **Nowa sesja** pobierz raport, jeśli chcesz zachować poprzedni przebieg.
