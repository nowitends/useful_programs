import vm from 'node:vm';
import fs from 'node:fs';
import assert from 'node:assert/strict';
import os from 'node:os';
import path from 'node:path';
import {execFileSync} from 'node:child_process';

const root=path.resolve(import.meta.dirname,'..');
const source=fs.readFileSync(path.join(root,'src/app.js'),'utf8');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
class FakeElement {
  constructor(){this.style={};this.className='';this.value='';this.hidden=false;this.disabled=false;this.textContent='';this.children=[];this.events={};this.attrs={};}
  addEventListener(event,callback){this.events[event]=callback;}
  replaceChildren(...children){this.children=[...children];}
  appendChild(child){this.children.push(child);}
  append(...children){this.children.push(...children);}
  setAttribute(k,v){this.attrs[k]=v;}
  focus(){} select(){} querySelector(){return new FakeElement();}
}
const elements=new Map();
const document={getElementById(id){if(!elements.has(id))elements.set(id,new FakeElement());return elements.get(id);},createElement(){return new FakeElement();},addEventListener(){},body:new FakeElement()};
const storage=new Map();
let nextTimer=0;
const queuedTimers=new Map();
const window={scrollTo(){},confirm(){return true;},clearTimeout(id){queuedTimers.delete(id);},setTimeout(callback){const id=++nextTimer;queuedTimers.set(id,callback);return id;}};
const context=vm.createContext({document,window,localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v),removeItem:k=>storage.delete(k)},crypto:globalThis.crypto,TextEncoder,Blob,URL,btoa,console,Date,Uint8Array,Math});
vm.runInContext(source,context,{filename:'app.js'});
const run=expr=>vm.runInContext(expr,context);
function flush(){const timers=[...queuedTimers.entries()];queuedTimers.clear();for(const [,fn] of timers)fn();}
function answer(value){elements.get('code-input').value=value;run('nextQuestion()');}
function current(){return run('state.index');}

assert.equal(run('EXERCISES.length'),18);
assert.equal(run('EXERCISES.every(e=>e.answers.length>0&&typeof PREVIEW[e.preview]==="function")'),true);
assert.equal(run('EXERCISES.filter(e=>e.id==="frac").length'),1);
assert.equal(run('EXERCISES.some(e=>e.id==="cross"||e.id==="reals")'),false);
assert.equal(run('EXERCISES[13].id'),'label');
assert.equal(run('EXERCISES[14].id'),'eqref');
assert.equal(run('EXERCISES.filter(q=>q.prefix.includes(String.raw`\[`)).length'),0);
assert.match(html,/<pre class="sample-code"[^>]*>\$\$/);
assert.ok(!html.includes('id="github-input"'));
assert.ok(!html.includes('id="name-input"'));
assert.ok(html.includes('Wpisz inicjały'));
assert.ok(html.includes('Wpisz kod'));
assert.ok(html.includes('EDYCJA 04 · 18 ZADAŃ'));
assert.ok(html.includes('id="back-button"'));
assert.equal(run('isCorrect(EXERCISES[7], String.raw`\\Sigma`)'),true);
assert.equal(run('isCorrect(EXERCISES[7], String.raw`\\sum`)'),true);

// Invalid initials and access code must not start a session.
elements.get('initials-input').value='R';
elements.get('pin-input').value='0000';
run('onStart({preventDefault(){}})');
assert.equal(run('state'),null);
elements.get('initials-input').value='r.d.';
elements.get('pin-input').value='1234';
run('onStart({preventDefault(){}})');
assert.equal(run('state'),null);
elements.get('pin-input').value='0000';
run('onStart({preventDefault(){}})');
assert.equal(run('state.user.initials'),'RD');
assert.equal(current(),0);
answer(run('EXERCISES[0].answers[0]'));
assert.equal(current(),0,'Correct response appears briefly before advancing');
flush();assert.equal(current(),1);
run('backQuestion()');
assert.equal(current(),0);
assert.equal(run('state.results[0].attempts.length'),1);
run('nextQuestion()');assert.equal(current(),1);
answer('');assert.equal(current(),2);
assert.equal(run('state.results[1].skipReason'),'empty');
assert.equal(run('state.results[1].attempts.length'),0);
run('backQuestion()');assert.equal(current(),1);
answer(run('EXERCISES[1].answers[0]'));
flush();assert.equal(current(),2);
assert.equal(run('state.results[1].status'),'correct');
for(let i=0;i<5;i++){
  answer('invalid_'+i);
  assert.equal(run('state.results[2].attempts.length'),i+1);
}
assert.equal(run('state.results[2].skipReason'),'limit');
flush();assert.equal(current(),3);
for(let i=3;i<18;i++){
  answer(run(`EXERCISES[${i}].answers[0]`));flush();
  assert.equal(current(),i+1,'Exercise '+(i+1));
}
assert.equal(run('state.finishedAt!==null'),true);
assert.equal(run('buildReport().version'),4);
assert.equal(run('buildReport().student.initials'),'RD');
assert.equal(run('buildReport().summary.total'),18);
assert.equal(run('buildReport().summary.correct'),17);
assert.equal(run('buildReport().summary.skippedLimit'),1);
assert.equal(run('buildReport().summary.skippedEmpty'),0);
assert.equal(run('buildReport().summary.attempts'),22);
assert.equal(run('document.getElementById("code-input").value=EXERCISES[0].answers[0];resizeInput();document.getElementById("code-input").style.width'),'8.35ch');
const temp=fs.mkdtempSync(path.join(os.tmpdir(),'latexdrill-v4-test-'));
const file=path.join(temp,'result.txt');
fs.writeFileSync(file,run('encodeReport(buildReport())'));
const decoder=path.join(root,'teacher','decode.py');
let output=execFileSync('python',[decoder,file,'--details','--csv',path.join(temp,'wyniki.csv'),'--json-dir',path.join(temp,'json')],{encoding:'utf8'});
assert.match(output,/17\/18/);
assert.match(output,/LIMIT/);
assert.match(output,/Inicjały: RD/);
assert.ok(fs.readFileSync(path.join(temp,'wyniki.csv'),'utf8').includes('inicjaly'));
const json=JSON.parse(fs.readFileSync(path.join(temp,'json','result.json'),'utf8'));
assert.equal(json.student.initials,'RD');
assert.equal(json.exercises.length,18);

// Empty answers skip questions without using attempts.
run('state=startSession({initials:"AB"});renderQuestion()');
for(let i=0;i<18;i++)answer('');
assert.equal(run('buildReport().summary.skippedEmpty'),18);
assert.equal(run('buildReport().summary.attempts'),0);
fs.writeFileSync(file,run('encodeReport(buildReport())'));
output=execFileSync('python',[decoder,file,'--details'],{encoding:'utf8'});
assert.match(output,/0\/18/);
assert.match(output,/PUSTE/);

// Historical reports must still decode correctly.
const oldV3=path.join(root,'tests','sample-v3.txt');
const oldV2=path.join(root,'tests','sample-valid-v2.txt');
assert.match(execFileSync('python',[decoder,oldV3],{encoding:'utf8'}),/V3/);
assert.match(execFileSync('python',[decoder,oldV2],{encoding:'utf8'}),/V2/);
console.log('PASS: 18 tasks, initials, PIN, no legacy identity fields, navigation, 5 attempts, empty skip, TXT v4, Python decoder V2–V4, CSV and JSON.');
