'use strict';

/* LaTeX Drill Lab 4.0 — standalone, no network or backend.
 * NOTE: the access code and solutions are necessarily visible in the browser.
 * TXT is obfuscated for convenient marking, NOT cryptographically secured.
 */
const EXERCISES = [
  {
    id:'section', category:'STRUKTURA', title:'Nowa sekcja',
    instruction:'Utwórz numerowaną sekcję o nazwie „Wprowadzenie”. Wpisz tylko brakującą komendę.',
    prefix:String.raw`\begin{document}
`,suffix:String.raw`{Wprowadzenie}
\end{document}`,
    answers:[String.raw`\section`], hint:'Komenda ma nazwę taką samą jak angielskie słowo „sekcja”.', preview:'section'
  },
  {
    id:'subsection', category:'STRUKTURA', title:'Podsekcja',
    instruction:'Podziel sekcję na mniejsze części. Utwórz numerowaną podsekcję „Założenia”.',
    prefix:String.raw`\section{Wprowadzenie}
`,suffix:String.raw`{Założenia}`,
    answers:[String.raw`\subsection`], hint:'Do słowa „section” dodaj przedrostek „sub”.', preview:'subsection'
  },
  {
    id:'toc', category:'STRUKTURA', title:'Automatyczny spis treści',
    instruction:'Wstaw komendę, która generuje spis treści dokumentu.',
    prefix:String.raw`\begin{document}
`,suffix:String.raw`
\section{Wprowadzenie}
\section{Metody}
\end{document}`,
    answers:[String.raw`\tableofcontents`], hint:'Po angielsku: „table of contents” — połącz wyrazy.', preview:'toc'
  },
  {
    id:'equation', category:'MATEMATYKA', title:'Równanie z numerem',
    instruction:'Wpisz nazwę środowiska, które wyświetli równanie z automatycznym numerem po prawej stronie.',
    prefix:String.raw`\begin{`,suffix:String.raw`}
  E = mc^2
\end{equation}`,
    answers:['equation'], hint:'Nazwa środowiska to po angielsku „równanie”. Nie dodawaj gwiazdki.', preview:'equation'
  },
  {
    id:'frac', category:'MATEMATYKA', title:'Pierwszy ułamek',
    instruction:'Utwórz ułamek z licznikiem a+b i mianownikiem c.',
    prefix:String.raw`$$
  `,suffix:String.raw`{a+b}{c}
$$`,
    answers:[String.raw`\frac`,String.raw`\dfrac`], hint:'Nazwa komendy pochodzi od angielskiego „fraction”.', preview:'frac'
  },
  {
    id:'sqrt', category:'MATEMATYKA', title:'Pierwiastek z x²',
    instruction:'Zapisz pierwiastek kwadratowy z x². Klamry z wyrażeniem są już podane.',
    prefix:String.raw`$$
  `,suffix:String.raw`{x^2}
$$`,
    answers:[String.raw`\sqrt`], hint:'Angielski skrót od „square root”.', preview:'sqrt'
  },
  {
    id:'integral', category:'MATEMATYKA', title:'Całka oznaczona',
    instruction:'Wstaw symbol całki od 0 do 1 z funkcji x².',
    prefix:String.raw`$$
  `,suffix:String.raw`_{0}^{1} x^2\,dx
$$`,
    answers:[String.raw`\int`], hint:'Komenda do całki ma trzy litery po ukośniku.', preview:'integral'
  },
  {
    id:'sum', category:'MATEMATYKA', title:'Symbol sumowania',
    instruction:'Utwórz sumę dla k od 1 do n. W tym ćwiczeniu akceptujemy zarówno operator sumowania, jak i wielką grecką sigmę.',
    prefix:String.raw`$$
  `,suffix:String.raw`_{k=1}^{n} k
$$`,
    answers:[String.raw`\sum`,String.raw`\Sigma`], hint:'Dwie dopuszczalne formy: trzy litery słowa „sum” lub duża grecka sigma.', preview:'sum'
  },
  {
    id:'superscript', category:'INDEKSY', title:'Indeks górny',
    instruction:'Uzupełnij wzór na energię tak, aby przy c pojawiła się dwójka w indeksie górnym.',
    prefix:String.raw`$$
  E = mc`,suffix:String.raw`
$$`,
    answers:['^2','^{2}'], hint:'Indeks górny wprowadza znak ^. Cyfrę można ująć w klamry.', preview:'superscript'
  },
  {
    id:'subscript', category:'INDEKSY', title:'Dwa indeksy dolne',
    instruction:'Dodaj do g dwa greckie indeksy dolne: μ i ν. Zwróć uwagę na wspólne klamry.',
    prefix:String.raw`$$
  g`,suffix:String.raw` = \eta_{\mu\nu}+h_{\mu\nu}
$$`,
    answers:[String.raw`_{\mu\nu}`], hint:'Indeks dolny zaczyna się znakiem _, a dwa symbole ujmij razem w {…}.', preview:'subscript'
  },
  {
    id:'inline-math', category:'TEKST I MATEMATYKA', title:'Tensor w zwykłym zdaniu',
    instruction:'Wstaw do zdania symbol tensora metrycznego g z indeksami μν, używając trybu matematycznego wewnątrz tekstu.',
    prefix:'Tensor metryczny ',suffix:' opisuje geometrię czasoprzestrzeni.',
    answers:[String.raw`$g_{\mu\nu}$`,String.raw`\(g_{\mu\nu}\)`],
    hint:'Wzór w tekście możesz otoczyć znakami $…$ albo ogranicznikami \\( … \\).', preview:'inline-math'
  },
  {
    id:'union', category:'ZBIORY', title:'Suma dwóch zbiorów',
    instruction:'Zapisz sumę zbiorów A oraz B, czyli ich unię.',
    prefix:String.raw`$$
  A `,suffix:String.raw` B
$$`,
    answers:[String.raw`\cup`], hint:'Użyj polecenia na symbol unii zbiorów, odpowiadającego kształtowi ∪.', preview:'union'
  },
  {
    id:'vector', category:'WEKTORY', title:'Strzałka nad wektorem',
    instruction:'Dodaj strzałkę nad literą v. Składowe wektora są już wpisane.',
    prefix:String.raw`$$
  `,suffix:String.raw`{v}=(v_1,v_2,v_3)
$$`,
    answers:[String.raw`\vec`,String.raw`\overrightarrow`], hint:'Standardowa krótka komenda wektorowa zaczyna się od \\v…', preview:'vector'
  },
  {
    id:'label', category:'ODNOŚNIKI', title:'Etykieta równania',
    instruction:'Przypisz równaniu etykietę „eq:energia”, aby móc się do niego odwoływać.',
    prefix:String.raw`\begin{equation}
  E=mc^2
  `,suffix:String.raw`{eq:energia}
\end{equation}`,
    answers:[String.raw`\label`], hint:'Angielska nazwa komendy dosłownie oznacza „etykietę”.', preview:'label'
  },
  {
    id:'eqref', category:'ODNOŚNIKI', title:'Odwołanie do równania',
    instruction:'Zacytuj numer oznaczonego równania, automatycznie umieszczając go w nawiasach.',
    prefix:'Z równania~',suffix:'{eq:energia} wynika, że...',
    answers:[String.raw`\eqref`], hint:'W pakiecie amsmath łączy się skróty „eq” i „ref”.', preview:'eqref'
  },
  {
    id:'bold', category:'FORMATOWANIE', title:'Pogrubienie tekstu',
    instruction:'Wyróżnij słowa „ważny wynik” tekstem pogrubionym.',
    prefix:'To jest ',suffix:'{ważny wynik}.',
    answers:[String.raw`\textbf`], hint:'Skróty od „text” i „boldface”.', preview:'bold'
  },
  {
    id:'itemize', category:'STRUKTURA', title:'Lista punktowana',
    instruction:'Wybierz nazwę środowiska dla listy z punktorami, a nie numerami.',
    prefix:String.raw`\begin{`,suffix:String.raw`}
  \item Pierwszy krok
  \item Drugi krok
\end{itemize}`,
    answers:['itemize'], hint:'Nazwa środowiska zaczyna się od „item”.', preview:'itemize'
  },
  {
    id:'matrix', category:'MATEMATYKA', title:'Macierz w nawiasach',
    instruction:'Wpisz środowisko tworzące macierz 2×2 w okrągłych nawiasach.',
    prefix:String.raw`$$
\begin{`,suffix:String.raw`}
  1 & 2 \\
  3 & 4
\end{pmatrix}
$$`,
    answers:['pmatrix'], hint:'Nazwa składa się z litery p (parentheses) i słowa matrix.', preview:'matrix'
  }
];

const TOTAL = EXERCISES.length;
const STORAGE_KEY = 'latex-drill-lab-v4-session';
const $ = id => document.getElementById(id);
const el = {
  start:$('start-screen'),work:$('work-screen'),done:$('done-screen'),
  form:$('start-form'),initials:$('initials-input'),pin:$('pin-input'),formError:$('form-error'),startBtn:$('start-button'),
  tag:$('student-tag'),navStat:$('nav-stat'),newSession:$('new-session'),
  progressTitle:$('progress-title'),progressStats:$('progress-stats'),progressGrid:$('progress-grid'),progressFoot:$('progress-foot'),
  taskNumber:$('task-number'),taskCategory:$('task-category'),taskTitle:$('task-title'),taskInstruction:$('task-instruction'),
  codePrefix:$('code-prefix'),codeSuffix:$('code-suffix'),codeInput:$('code-input'),numbers:$('line-numbers'),
  check:$('check-button'),back:$('back-button'),attempts:$('attempt-dots'),feedback:$('feedback'),feedbackIcon:$('feedback-icon'),feedbackText:$('feedback-text'),hint:$('hint-box'),
  previewCard:$('preview-card'),preview:$('preview-paper'),previewStatus:$('preview-status'),previewFooter:$('preview-footer'),
  scoreCorrect:$('score-correct'),scoreSkip:$('score-skipped'),scoreAttempts:$('score-attempts'),results:$('results-list'),download:$('download-button'),review:$('review-button')
};
let state = null;
let transitionTimer = null;
let feedbackKind = '';
function normalize(s){return String(s).trim();}
function isCorrect(q,value){return q.answers.some(a=>normalize(a)===normalize(value));}
function makeId(){
  const array=new Uint8Array(8);
  if(globalThis.crypto?.getRandomValues)crypto.getRandomValues(array);
  else for(let i=0;i<array.length;i++)array[i]=Math.floor(Math.random()*256);
  return Array.from(array,v=>v.toString(16).padStart(2,'0')).join('');
}
function save(){try{localStorage.setItem(STORAGE_KEY,JSON.stringify(state));}catch(e){}}
function readSaved(){
  try{
    const obj=JSON.parse(localStorage.getItem(STORAGE_KEY)||'null');
    if(!obj||obj.schema!=='latex-drill-v4'||!obj.user||!Array.isArray(obj.results)||obj.results.length!==TOTAL||!Number.isInteger(obj.index)||obj.index<0||obj.index>TOTAL)return null;
    if(!obj.results.every((r,i)=>r.id===EXERCISES[i].id&&Array.isArray(r.attempts)&&r.attempts.length<=5))return null;
    return obj;
  }catch(e){return null;}
}
function clearTransition(){if(transitionTimer!==null){window.clearTimeout(transitionTimer);transitionTimer=null;}}
function startSession(user){return {schema:'latex-drill-v4',sessionId:makeId(),startedAt:new Date().toISOString(),finishedAt:null,user,index:0,results:EXERCISES.map((q,i)=>({id:q.id,number:i+1,title:q.title,status:'pending',skipReason:null,attempts:[],draft:''}))};}
function show(screen){
  el.start.hidden=screen!=='start';el.work.hidden=screen!=='work';el.done.hidden=screen!=='done';
  el.navStat.style.display=screen==='start'?'none':'inline';
  el.newSession.hidden=screen==='start';
  window.scrollTo({top:0,behavior:'instant'});
}
function setFeedback(message,kind=''){
  feedbackKind=kind;
  el.feedback.className='feedback'+(kind?' is-'+kind:'');
  el.feedbackIcon.textContent=kind==='success'?'✓':kind==='error'?'!':kind==='skip'?'↷':'i';
  el.feedbackText.textContent=message;
}
function updateDots(r){
  el.attempts.replaceChildren();
  for(let i=0;i<5;i++){
    const span=document.createElement('span');span.className='attempt-dot'+(i<r.attempts.length?' used':'');
    if(i===r.attempts.length-1&&r.status==='correct')span.className='attempt-dot good';
    el.attempts.appendChild(span);
  }
  el.attempts.setAttribute('aria-label',`${r.attempts.length} z 5 prób wykorzystanych`);
}
function drawProgress(){
  const completed=state.results.filter(r=>r.status==='correct'||r.status==='skipped').length;
  const correct=state.results.filter(r=>r.status==='correct').length;
  const skipped=state.results.filter(r=>r.status==='skipped').length;
  el.progressGrid.replaceChildren();
  state.results.forEach((r,i)=>{
    const cell=document.createElement('div');
    cell.className='step'+(r.status==='correct'?' ok':r.status==='skipped'?' skip':i===state.index?' active':'');
    cell.textContent=r.status==='correct'?'✓':r.status==='skipped'?'–':String(i+1);
    cell.title=`Zadanie ${i+1}: ${r.status==='correct'?'zaliczone':r.status==='skipped'?'pominięte':i===state.index?'bieżące':'oczekuje'}`;
    if(i===state.index)cell.setAttribute('aria-current','step');
    el.progressGrid.appendChild(cell);
  });
  el.progressTitle.textContent=`Zadanie ${Math.min(state.index+1,TOTAL)} z ${TOTAL}`;
  el.progressStats.textContent=`${correct} poprawnych · ${skipped} pominiętych`;
  el.progressFoot.textContent=`${completed} z ${TOTAL} zadań zakończonych`;
  el.navStat.textContent=`${completed} / ${TOTAL}`;
}
function resizeInput(){
  // Native monospaced width, with no artificial 3-character gap before a closing brace.
  const value=el.codeInput.value;
  el.codeInput.style.width=(value.length?Math.max(2,value.length+0.35):2.3)+'ch';
}
function previewMath(inner){return `<div class="math-wrap"><math xmlns="http://www.w3.org/1998/Math/MathML" display="block">${inner}</math></div>`;}
const MI=(s)=>`<mi>${s}</mi>`;
const MN=(s)=>`<mn>${s}</mn>`;
const MO=(s)=>`<mo>${s}</mo>`;
const mul=(...items)=>`<mrow>${items.join('')}</mrow>`;
const SUP=(x,s)=>`<msup>${x}${s}</msup>`;
const SUB=(x,s)=>`<msub>${x}${s}</msub>`;
const vec=(x)=>`<mover accent="true">${MI(x)}${MO('→')}</mover>`;
const energy=mul(MI('E'),MO('='),MI('m'),SUP(MI('c'),MN('2')));
function equation(inner,num='(1)'){return `<div class="equation-row"><div class="math-wrap" style="grid-column:2"><math xmlns="http://www.w3.org/1998/Math/MathML" display="block">${inner}</math></div><span class="equation-number">${num}</span></div>`;}
const PREVIEW = {
  section:()=>`<div class="paper-doc"><div class="section">1 Wprowadzenie</div><p>Treść pierwszej sekcji dokumentu.</p></div>`,
  subsection:()=>`<div class="paper-doc"><div class="section" style="font-size:18px;margin-bottom:17px">1 Wprowadzenie</div><div class="subsection">1.1 Założenia</div><p>Treść podsekcji.</p></div>`,
  toc:()=>`<div class="paper-doc"><div class="toc-title">Spis treści</div><div class="toc-row"><span>1 Wprowadzenie</span><i></i><span>1</span></div><div class="toc-row"><span>2 Metody</span><i></i><span>2</span></div></div>`,
  equation:()=>equation(energy),
  frac:()=>previewMath(`<mfrac>${mul(MI('a'),MO('+'),MI('b'))}${MI('c')}</mfrac>`),
  sqrt:()=>previewMath(`<msqrt>${SUP(MI('x'),MN('2'))}</msqrt>`),
  integral:()=>previewMath(mul(`<msubsup>${MO('∫')}${MN('0')}${MN('1')}</msubsup>`,SUP(MI('x'),MN('2')),MI('d'),MI('x'))),
  sum:(answer)=>{
    const lower=mul(MI('k'),MO('='),MN('1'));
    const op=normalize(answer)===String.raw`\Sigma` ? `<msubsup>${MI('Σ')}${lower}${MI('n')}</msubsup>` : `<munderover>${MO('∑')}${lower}${MI('n')}</munderover>`;
    return previewMath(mul(op,MI('k')));
  },
  superscript:()=>previewMath(energy),
  subscript:()=>previewMath(mul(SUB(MI('g'),mul(MI('μ'),MI('ν'))),MO('='),SUB(MI('η'),mul(MI('μ'),MI('ν'))),MO('+'),SUB(MI('h'),mul(MI('μ'),MI('ν'))))),
  'inline-math':()=>`<div class="paper-doc"><div class="inline-text">Tensor metryczny <math xmlns="http://www.w3.org/1998/Math/MathML" display="inline"><msub><mi>g</mi><mrow><mi>μ</mi><mi>ν</mi></mrow></msub></math> opisuje geometrię czasoprzestrzeni.</div></div>`,
  union:()=>previewMath(mul(MI('A'),MO('∪'),MI('B'))),
  vector:()=>previewMath(mul(vec('v'),MO('='),MO('('),SUB(MI('v'),MN('1')),MO(','),SUB(MI('v'),MN('2')),MO(','),SUB(MI('v'),MN('3')),MO(')'))),
  label:()=>`<div style="width:100%">${equation(energy)}<div class="paper-doc" style="text-align:center"><div class="label-meta">Etykieta „eq:energia” nie jest drukowana.</div></div></div>`,
  eqref:()=>`<div class="paper-doc"><p class="inline-text">Z równania <b>(1)</b> wynika, że...</p></div>`,
  bold:()=>`<div class="paper-doc"><p class="inline-text">To jest <span class="bold-text">ważny wynik</span>.</p></div>`,
  itemize:()=>`<div class="paper-doc"><ul><li>Pierwszy krok</li><li>Drugi krok</li></ul></div>`,
  matrix:()=>previewMath(mul(`<mo stretchy="true">(</mo><mtable columnspacing="1.1em" rowspacing=".4em"><mtr><mtd>${MN('1')}</mtd><mtd>${MN('2')}</mtd></mtr><mtr><mtd>${MN('3')}</mtd><mtd>${MN('4')}</mtd></mtr></mtable><mo stretchy="true">)</mo>`))
};
function updatePreview(){
  const q=EXERCISES[state.index];if(!q)return;
  const answer=el.codeInput.value;
  const valid=isCorrect(q,answer);
  const r=state.results[state.index];
  el.preview.innerHTML=valid?PREVIEW[q.preview](answer):`<div class="preview-placeholder"><div class="preview-placeholder-icon" aria-hidden="true">⌘</div><h3>${answer.trim()?'Brak oczekiwanego efektu':'Podgląd pojawi się tutaj'}</h3><p>${answer.trim()?'Sprawdź składnię polecenia.':'Wpisz polecenie w podkreśloną lukę.'}</p></div>`;
  const kind=feedbackKind||(r.status==='correct'?'success':r.status==='skipped'?'skip':'');
  el.previewCard.className='card preview-card'+(kind?' is-'+kind:'');
  el.previewStatus.textContent=kind==='success'?'Poprawnie':kind==='error'?'Błędna odpowiedź':kind==='skip'?'Pominięto':'Podgląd na żywo';
  el.previewFooter.textContent=valid&&q.id==='sum'&&normalize(answer)===String.raw`\Sigma`?'Wielka litera Σ — tu akceptowana, choć nie jest operatorem sumowania':valid?'Efekt zadanego fragmentu LaTeX-a':'Uproszczony podgląd, bez kompilacji TeX-a';
}
function canEdit(r){return r.status==='pending'||(r.status==='skipped'&&r.skipReason==='empty'&&r.attempts.length<5);}
function renderQuestion(){
  clearTransition();
  if(state.index>=TOTAL){renderDone();return;}
  const q=EXERCISES[state.index],r=state.results[state.index];
  el.tag.textContent=state.user.initials;
  el.taskNumber.textContent='ZADANIE '+String(state.index+1).padStart(2,'0')+' / '+TOTAL;
  el.taskCategory.textContent=q.category;
  el.taskTitle.textContent=q.title;
  el.taskInstruction.textContent=q.instruction;
  el.codePrefix.textContent=q.prefix;el.codeSuffix.textContent=q.suffix;
  el.numbers.textContent=Array.from({length:Math.max(3,(q.prefix+q.suffix).split('\n').length)},(_,i)=>i+1).join('\n');
  el.codeInput.value=r.draft||'';
  el.codeInput.disabled=!canEdit(r);
  el.codeInput.className='gap-input'+(r.status==='correct'?' is-right':r.skipReason==='limit'?' is-wrong':'');
  el.back.disabled=state.index===0;
  el.check.disabled=false;
  el.check.querySelector('.keycap').textContent='Enter';
  updateDots(r);drawProgress();resizeInput();
  el.hint.hidden=r.attempts.length<3||r.status==='correct';
  el.hint.textContent='Wskazówka: '+q.hint;
  if(r.status==='correct')setFeedback(`Zadanie zaliczone (${r.attempts.length}/5 prób). Wybierz „Dalej” lub „Cofnij”.`,'success');
  else if(r.skipReason==='limit')setFeedback('Wykorzystano 5 prób. Zadanie pominięte. Możesz przejść dalej.','skip');
  else if(r.status==='skipped')setFeedback('Wcześniej pominięto to zadanie. Możesz teraz odpowiedzieć lub ponownie wybrać „Dalej”.','skip');
  else if(r.attempts.length)setFeedback(`Wykorzystane próby: ${r.attempts.length}/5. Wpisz odpowiedź i wybierz „Dalej”.`,'error');
  else setFeedback('Uzupełnij lukę i wybierz „Dalej” (Enter). Puste pole oznacza pominięcie.');
  updatePreview();show('work');
  if(!el.codeInput.disabled)el.codeInput.focus({preventScroll:true});
}
function goForward(){
  clearTransition();
  if(!state||state.finishedAt||state.index>=TOTAL)return;
  state.index++;
  if(state.index>=TOTAL){state.finishedAt=new Date().toISOString();save();renderDone();}
  else{save();renderQuestion();}
}
function nextQuestion(){
  if(!state||state.finishedAt||state.index>=TOTAL||transitionTimer!==null)return;
  const r=state.results[state.index],q=EXERCISES[state.index];
  const answer=el.codeInput.value;
  r.draft=answer;
  if(!canEdit(r)){goForward();return;}
  if(!answer.trim()){
    r.status='skipped';r.skipReason='empty';r.skippedAt=new Date().toISOString();
    save();goForward();return;
  }
  const correct=isCorrect(q,answer);
  r.attempts.push({value:answer,correct,at:new Date().toISOString()});
  if(correct){
    r.status='correct';r.skipReason=null;
    el.codeInput.className='gap-input is-right';el.codeInput.disabled=true;
    setFeedback(`Poprawnie! ${r.attempts.length}/5 prób.`,'success');
  }else if(r.attempts.length>=5){
    r.status='skipped';r.skipReason='limit';r.skippedAt=new Date().toISOString();
    el.codeInput.className='gap-input is-wrong';el.codeInput.disabled=true;
    setFeedback('Pięć błędnych prób. Zadanie pominięte.','skip');
  }else{
    el.codeInput.className='gap-input is-wrong';
    setFeedback(`Jeszcze nie. Pozostało prób: ${5-r.attempts.length}.`,'error');
    el.hint.hidden=r.attempts.length<3;
    if(!el.hint.hidden)el.hint.textContent='Wskazówka: '+q.hint;
    el.codeInput.focus({preventScroll:true});el.codeInput.select();
  }
  save();drawProgress();updateDots(r);updatePreview();
  if(correct||r.skipReason==='limit'){
    el.check.disabled=true;
    // Short feedback flash, not the former 1.15-second wait.
    transitionTimer=window.setTimeout(()=>{transitionTimer=null;goForward();},260);
  }
}
function backQuestion(){
  if(!state||state.index<=0)return;
  clearTransition();
  if(state.index<TOTAL)state.results[state.index].draft=el.codeInput.value;
  state.index--;save();renderQuestion();
}
function renderDone(){
  clearTransition();
  const correct=state.results.filter(r=>r.status==='correct').length;
  const skipped=state.results.filter(r=>r.status==='skipped').length;
  const attempts=state.results.reduce((s,r)=>s+r.attempts.length,0);
  el.scoreCorrect.textContent=`${correct} / ${TOTAL}`;
  el.scoreSkip.textContent=String(skipped);
  el.scoreAttempts.textContent=String(attempts);
  el.results.replaceChildren();
  state.results.forEach((r,i)=>{
    const row=document.createElement('div');row.className='result-row';
    const num=document.createElement('span');num.className='result-num';num.textContent=String(i+1).padStart(2,'0');
    const title=document.createElement('span');title.className='result-name';title.textContent=r.title;
    const status=document.createElement('span');status.className='result-status'+(r.status==='skipped'?' skipped':'');
    const skippedText=r.skipReason==='empty'?'pominięte':r.skipReason==='limit'?'limit 5 prób':'pominięte';
    status.textContent=r.status==='correct'?`✓ ${r.attempts.length}/5`:`— ${skippedText}`;
    row.append(num,title,status);el.results.appendChild(row);
  });
  el.navStat.textContent=`${correct} / ${TOTAL} ✓`;
  show('done');
}
function reviewQuestions(){
  if(!state||!state.finishedAt)return;
  state.index=state.results.findIndex(r=>r.status==='skipped'&&r.skipReason==='empty');
  if(state.index<0)state.index=TOTAL-1;
  state.finishedAt=null;save();renderQuestion();
}
function buildReport(){
  return {
    format:'LATEX_DRILL_REPORT',version:4,authentication:'NONE_CLIENT_SIDE',
    sessionId:state.sessionId,student:{initials:state.user.initials},
    startedAt:state.startedAt,finishedAt:state.finishedAt,exportedAt:new Date().toISOString(),
    summary:{total:TOTAL,correct:state.results.filter(r=>r.status==='correct').length,skipped:state.results.filter(r=>r.status==='skipped').length,
      skippedEmpty:state.results.filter(r=>r.skipReason==='empty').length,skippedLimit:state.results.filter(r=>r.skipReason==='limit').length,
      attempts:state.results.reduce((s,r)=>s+r.attempts.length,0)},
    exercises:state.results.map(r=>({number:r.number,id:r.id,title:r.title,status:r.status,skipReason:r.skipReason,
      attempts:r.attempts.length,finalAnswer:r.attempts.at(-1)?.value||'',history:r.attempts}))
  };
}
function shiftChar(ch,delta){
  const c=ch.charCodeAt(0);
  if(c>=65&&c<=90)return String.fromCharCode(65+(c-65+delta+26)%26);
  if(c>=97&&c<=122)return String.fromCharCode(97+(c-97+delta+26)%26);
  if(c>=48&&c<=57)return String.fromCharCode(48+(c-48+delta+10)%10);
  return ch;
}
function encodeReport(report){
  const bytes=new TextEncoder().encode(JSON.stringify(report));
  let bin='';for(let i=0;i<bytes.length;i+=4096)bin+=String.fromCharCode(...bytes.subarray(i,i+4096));
  const encoded=btoa(bin);
  const rotated=Array.from(encoded,ch=>shiftChar(ch,1)).join('');
  const lines=rotated.match(/.{1,100}/g)||[];
  return 'LATEX-DRILL/18/V4\nFORMAT: UTF8-BASE64-CAESAR+1\nBEGIN-DATA\n'+lines.join('\n')+'\nEND-DATA\n';
}
function downloadTxt(){
  if(!state||!state.finishedAt)return;
  const data=encodeReport(buildReport());
  const blob=new Blob([data],{type:'text/plain;charset=utf-8'});
  const href=URL.createObjectURL(blob),a=document.createElement('a');
  const slug=state.user.initials.normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/ł/gi,'l').toLowerCase();
  a.href=href;a.download='latex-drill18_'+slug+'_'+state.sessionId+'.txt';
  document.body.append(a);a.click();a.remove();
  window.setTimeout(()=>URL.revokeObjectURL(href),1000);
}
function resetToStart(){
  clearTransition();state=null;
  try{localStorage.removeItem(STORAGE_KEY);}catch(e){}
  el.pin.value='';el.formError.hidden=true;
  el.startBtn.querySelector('.button-label').textContent='Rozpocznij ćwiczenia';
  show('start');el.initials.focus({preventScroll:true});
}
function normalizeInitials(raw){
  return String(raw).toLocaleUpperCase('pl-PL').replace(/[\s.]/g,'');
}
function onStart(event){
  event.preventDefault();
  const initials=normalizeInitials(el.initials.value),pin=el.pin.value.trim();
  if(!/^[A-ZĄĆĘŁŃÓŚŹŻ]{2,6}$/.test(initials)){
    el.formError.textContent='Wpisz 2–6 liter inicjałów (np. RD albo R.D.).';
    el.formError.hidden=false;el.initials.focus();return;
  }
  if(pin!=='0000'){
    el.formError.textContent='Nieprawidłowy czterocyfrowy kod dostępu.';el.formError.hidden=false;el.pin.focus();return;
  }
  el.formError.hidden=true;
  el.initials.value=initials;
  const cached=readSaved();
  if(cached&&!cached.finishedAt&&cached.user.initials===initials){
    state=cached;
  }else state=startSession({initials});
  save();renderQuestion();
}
el.form.addEventListener('submit',onStart);
el.check.addEventListener('click',nextQuestion);
el.back.addEventListener('click',backQuestion);
el.review.addEventListener('click',reviewQuestions);
el.download.addEventListener('click',downloadTxt);
el.newSession.addEventListener('click',()=>{
  if(window.confirm('Rozpocząć nową sesję? Najpierw pobierz raport TXT, jeśli chcesz zachować dotychczasowy wynik.'))resetToStart();
});
el.codeInput.addEventListener('input',()=>{
  if(!state||state.index>=TOTAL)return;
  const r=state.results[state.index];r.draft=el.codeInput.value;
  el.codeInput.className='gap-input';
  resizeInput();setFeedback('Wybierz „Dalej” (Enter), aby sprawdzić. Puste pole pomija zadanie.');
  updatePreview();save();
});
document.addEventListener('keydown',event=>{
  if(event.key!=='Enter'||event.repeat||el.work.hidden||!state)return;
  // Pressing Enter on "Cofnij" must still go backwards, not submit the answer.
  if(event.target===el.back)return;
  event.preventDefault();nextQuestion();
});
el.pin.addEventListener('input',()=>{el.formError.hidden=true;});
el.initials.addEventListener('input',()=>{el.formError.hidden=true;});
const savedOnLoad=readSaved();
if(savedOnLoad){
  el.initials.value=savedOnLoad.user.initials;
  if(!savedOnLoad.finishedAt)el.startBtn.querySelector('.button-label').textContent='Kontynuuj zapisane ćwiczenie';
}
show('start');
