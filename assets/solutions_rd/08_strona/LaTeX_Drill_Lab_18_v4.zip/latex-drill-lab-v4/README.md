# LaTeX Drill Lab 4.0 — 18 zadań (strona statyczna)

Pracownia komend LaTeX-a: **jeden samodzielny plik HTML**, bez serwera aplikacyjnego, API, bibliotek z CDN lub wymogu instalowania czegokolwiek przez studentów. Kod wejścia: `0000`.

## Uruchomienie i publikacja

- **Lokalnie:** otwórz `index.html` w przeglądarce.
- **GitHub Pages:** umieść `index.html` w głównym katalogu repozytorium. W jego `Settings → Pages` wybierz publikację z gałęzi (np. `main`, katalog `/ (root)`), jeśli ta opcja jest dostępna na koncie.
- Wszystkie style i skrypty są wbudowane w `index.html`. `src/` jest wersją źródłową do przyszłej edycji, nie trzeba go publikować.

## Ekran startowy

Student widzi **wyłącznie dwa pola** (w tej kolejności):

1. **Wpisz inicjały** — 2–6 liter, np. `RD`, `R.D.`, `rd` (normalizacja do `RD`); obsługiwane są polskie litery.
2. **Wpisz kod** — kod `0000`.

Nie ma pól loginu GitHub ani imienia i nazwiska. Identyfikatorem w pliku TXT są **inicjały** i losowy identyfikator sesji. Inicjały nie muszą być unikalne w grupie, dlatego przy sprawdzaniu należy dodatkowo uwzględniać ścieżkę repozytorium, z którego plik został odebrany.

## Przebieg

- Każde z **18 pytań** ma jedną edytowalną lukę, podgląd i przycisk **Dalej (Enter)**.
- Zła odpowiedź zużywa jedną z 5 prób. Po piątej błędnej próbie następuje automatyczne przejście dalej.
- **Puste pole + Dalej** oznacza pominięcie bez zużywania próby.
- **Cofnij** zachowuje liczbę prób. Można wrócić do pominiętej pustej odpowiedzi i odpowiedzieć; już zaliczone zadania są tylko do odczytu.
- Po zakończeniu wszystkich zadań przycisk **Pobierz raport .txt** zapisuje kodowane odpowiedzi, statusy i historię prób.
- Postęp zapisuje się w `localStorage` tej samej przeglądarki. **Nowa sesja** z górnego paska czyści bieżący przebieg; przed nią należy pobrać plik, jeśli ma zostać zachowany.

## Zadania

Zachowano pytania z poprzedniej edycji **z wyjątkiem dawnych numerów 14 i 15** (iloczyn wektorowy `\times` oraz liczby rzeczywiste `\mathbb`). Pozostałe pytania otrzymały aktualną numerację:

| Nr | Zagadnienie | Akceptowany fragment |
|---:|---|---|
| 1 | Sekcja | `\section` |
| 2 | Podsekcja | `\subsection` |
| 3 | Automatyczny spis treści | `\tableofcontents` |
| 4 | Numerowane równanie | `equation` |
| 5 | Ułamek | `\frac` lub `\dfrac` |
| 6 | Pierwiastek z kwadratu | `\sqrt` |
| 7 | Całka oznaczona | `\int` |
| 8 | Sumator | `\sum` lub `\Sigma` |
| 9 | Indeks górny | `^2` lub `^{2}` |
| 10 | Indeksy dolne tensora | `_{\mu\nu}` |
| 11 | Tensor w zdaniu | `$g_{\mu\nu}$` lub `\(g_{\mu\nu}\)` |
| 12 | Unia zbiorów | `\cup` |
| 13 | Strzałka nad wektorem | `\vec` lub `\overrightarrow` |
| 14 | Etykieta równania | `\label` |
| 15 | Odwołanie do równania | `\eqref` |
| 16 | Pogrubienie tekstu | `\textbf` |
| 17 | Lista punktowana | `itemize` |
| 18 | Macierz w okrągłych nawiasach | `pmatrix` |

Wszystkie przykłady matematyki wyświetlanej korzystają z `$$ ... $$`. Podgląd to uproszczona wizualizacja (MathML), a nie pełna kompilacja TeX. Dopuszczenie `\Sigma` zamiast `\sum` jest celową decyzją dydaktyczną: te dwa polecenia nie są równoważne w prawdziwym LaTeX-u.

## Dekodowanie plików studentów

**Tak, raport da się odkodować.** W tej edycji dane JSON kodowane są jako UTF-8 → Base64 → przesunięcie łacińskich liter **i cyfr** o +1 (z zawijaniem) → TXT. Dekoder wykonuje kroki odwrotne i tworzy także tabelę wyników.

Uruchom Python 3.10+ (tylko biblioteka standardowa):

```bash
python teacher/decode.py raport.txt --details
python teacher/decode.py folder_raportow/ --csv wyniki.csv
python teacher/decode.py folder_raportow/ --csv wyniki.csv --json-dir odczytane/
```

Przykładowa zawartość nagłówka raportu V4:

```text
LATEX-DRILL/18/V4
FORMAT: UTF8-BASE64-CAESAR+1
BEGIN-DATA
...zakodowany tekst...
END-DATA
```

Raport V4 zawiera `student.initials`, identyfikator sesji, daty, podsumowanie 18 odpowiedzi, status `correct/skipped`, powód pominięcia `empty/limit` i historię każdej wpisanej odpowiedzi. Raport V4 **nie zawiera loginu GitHub ani imienia i nazwiska**.

Weryfikator obsługuje również raporty **V2 i V3 z 20 zadaniami**. Przy zbiorczym eksporcie CSV liczba kolumn `Q01...` dopasowuje się do największej liczby zadań w zaimportowanych plikach (18 dla samych nowych raportów; do 20, gdy są również starsze).

> **Ograniczenie bezpieczeństwa:** Base64 i szyfr Cezara to **odwracalne kodowanie, a nie szyfrowanie chroniące przed fałszerstwem**. Kod `0000` i rozwiązania są dostępne w kodzie strony. Weryfikator sprawdza strukturę i wewnętrzną spójność danych, lecz nie może dowieść ich autentyczności. Rozwiązanie nadaje się do ćwiczeń dydaktycznych na zasadzie zaufania, a nie do egzaminu wymagającego zabezpieczeń.

## Rozwój i testowanie

```text
index.html              gotowa strona do publikacji
src/page.html           HTML
src/styles.css          CSS
src/app.js              zadania, logika, raport TXT
build.py                łączenie trzech plików w index.html
teacher/decode.py       dekoder raportów V4 / V3 / V2
tests/functional.mjs    testy w Node.js
INSTRUKCJA_STUDENT.md   instrukcja do przekazania studentom
```

Regenerowanie strony po edycji plików `src/`:

```bash
python build.py
node tests/functional.mjs
```

Testy weryfikują usunięcie obu zadań, sam formularz z inicjałami, cofanie, pomijanie, pięć prób, zapis TXT, odczyt CSV/JSON i zgodność z wcześniejszymi wersjami. Ponadto formularz i licznik postępu sprawdzono w Chromium. Nie potrzeba dostępu do Internetu do działania ćwiczenia.
