#!/usr/bin/env python3
"""Build fully standalone HTML (no network and no build dependencies)."""
from pathlib import Path
ROOT = Path(__file__).resolve().parent
html = (ROOT / 'src/page.html').read_text(encoding='utf-8')
html = html.replace('/*INLINE_CSS*/', (ROOT / 'src/styles.css').read_text(encoding='utf-8'))
html = html.replace('/*INLINE_JS*/', (ROOT / 'src/app.js').read_text(encoding='utf-8'))
(ROOT / 'index.html').write_text(html, encoding='utf-8')
print(f"Zbudowano: {ROOT/'index.html'} ({(ROOT/'index.html').stat().st_size} B)")
